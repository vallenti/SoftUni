﻿namespace BuhtigIssueTracker.Models
{
    public enum IssuePriority
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Showstopper = 4
    }
}
