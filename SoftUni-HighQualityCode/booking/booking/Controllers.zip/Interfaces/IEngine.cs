﻿namespace HotelBookingSystem.Interfaces
{
    public interface IEngine
    {
        void StartOperation();
    }
}
